<?php
session_start();
include "config/koneksi.php";

$error = "";

if (isset($_POST['login'])) {

    $username = mysqli_real_escape_string($conn, $_POST['username']);
    $password = $_POST['password'];

    $query = mysqli_query($conn, "SELECT * FROM users WHERE username='$username'");
    $user = mysqli_fetch_assoc($query);

    if ($user && password_verify($password, $user['password'])) {

        $_SESSION['id_user'] = $user['id_user'];
        $_SESSION['username'] = $user['username'];
        $_SESSION['role'] = $user['role'];

        if ($user['role'] == 'admin') {

            header("Location: admin/dashboard.php");
            exit;

        } elseif ($user['role'] == 'nasabah') {

            header("Location: nasabah/dashboard.php");
            exit;

        } else {

            $error = "Role akun tidak dikenali.";
        }

    } else {

        $error = "Username atau password salah!";
    }
}
?>

<!DOCTYPE html>
<html lang="id">

<head>

    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Login — ECOBANK</title>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">

    <link href="https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;500;600;700&family=Playfair+Display:wght@600;700&display=swap" rel="stylesheet">

    <style>

        body {
            margin: 0;
            min-height: 100vh;
            font-family: 'DM Sans', sans-serif;
            background: #f4f6ef;
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .login-wrapper {
            width: 900px;
            max-width: 95%;
            min-height: 560px;
            background: white;
            border-radius: 30px;
            overflow: hidden;
            box-shadow: 0 25px 70px rgba(30,70,50,.15);
        }

        .left {
            background: #174c38;
            color: white;
            padding: 60px;
            display: flex;
            flex-direction: column;
            justify-content: center;
            min-height: 560px;
        }

        .logo {
            font-size: 28px;
            font-weight: 700;
            letter-spacing: 1px;
            margin-bottom: 40px;
        }

        .logo span {
            color: #9bc47c;
        }

        .left h1 {
            font-family: 'Playfair Display', serif;
            font-size: 46px;
            line-height: 1.15;
        }

        .left p {
            color: #c8d9d0;
            line-height: 1.8;
            margin-top: 20px;
        }

        .right {
            padding: 60px;
            display: flex;
            flex-direction: column;
            justify-content: center;
        }

        .right h2 {
            font-family: 'Playfair Display', serif;
            color: #173f30;
            font-size: 38px;
        }

        .subtitle {
            color: #75847d;
            margin-bottom: 30px;
        }

        .form-label {
            font-weight: 600;
            color: #365247;
        }

        .form-control {
            padding: 13px 16px;
            border-radius: 12px;
            border: 1px solid #dfe6df;
        }

        .form-control:focus {
            border-color: #6c9d55;
            box-shadow: 0 0 0 3px rgba(108,157,85,.12);
        }

        .btn-login {
            width: 100%;
            border: none;
            background: #174c38;
            color: white;
            padding: 14px;
            border-radius: 12px;
            font-weight: 600;
            margin-top: 10px;
        }

        .btn-login:hover {
            background: #0e3829;
        }

        .back {
            display: block;
            text-align: center;
            margin-top: 25px;
            color: #65806f;
            text-decoration: none;
        }

        .back:hover {
            color: #174c38;
        }

        @media (max-width: 768px) {

            .login-wrapper {
                margin: 20px;
            }

            .left,
            .right {
                padding: 40px 30px;
                min-height: auto;
            }

            .left h1 {
                font-size: 36px;
            }

            .right h2 {
                font-size: 32px;
            }
        }

    </style>

</head>

<body>

<div class="login-wrapper">

    <div class="row g-0">

        <!-- LEFT -->
        <div class="col-md-6 left">

            <div class="logo">
                ECO<span>BANK</span>
            </div>

            <h1>
                Selamat Datang
                Kembali.
            </h1>

            <p>
                Kelola setoran sampah, pantau saldo,
                dan ikut berkontribusi menciptakan
                lingkungan yang lebih baik.
            </p>

        </div>


        <!-- RIGHT -->
        <div class="col-md-6 right">

            <h2>Masuk</h2>

            <p class="subtitle">
                Masuk ke akun ECOBANK kamu.
            </p>

            <?php if ($error): ?>

                <div class="alert alert-danger">
                    <?= htmlspecialchars($error) ?>
                </div>

            <?php endif; ?>


            <form method="POST">

                <div class="mb-3">

                    <label class="form-label">
                        Username
                    </label>

                    <input
                        type="text"
                        name="username"
                        class="form-control"
                        placeholder="Masukkan username"
                        required
                    >

                </div>


                <div class="mb-3">

                    <label class="form-label">
                        Password
                    </label>

                    <input
                        type="password"
                        name="password"
                        class="form-control"
                        placeholder="Masukkan password"
                        required
                    >

                </div>


                <button
                    type="submit"
                    name="login"
                    class="btn-login"
                >
                    Masuk ke ECOBANK
                </button>

            </form>


            <a href="index.php" class="back">
                ← Kembali ke Beranda
            </a>

        </div>

    </div>

</div>

</body>
</html>