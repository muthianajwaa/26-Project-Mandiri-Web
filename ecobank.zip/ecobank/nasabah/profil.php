<?php
session_start();
include "../config/koneksi.php";

if (!isset($_SESSION['id_user']) || $_SESSION['role'] != 'nasabah') {
    header("Location: ../login.php");
    exit;
}

$id_user = $_SESSION['id_user'];

$pesan = "";
$tipe = "";


/* UPDATE PROFIL */

if (isset($_POST['simpan'])) {

    $nama = mysqli_real_escape_string($conn, $_POST['nama']);
    $alamat = mysqli_real_escape_string($conn, $_POST['alamat']);
    $no_hp = mysqli_real_escape_string($conn, $_POST['no_hp']);

    $update = mysqli_query($conn, "
        UPDATE nasabah
        SET
            nama = '$nama',
            alamat = '$alamat',
            no_hp = '$no_hp'
        WHERE id_user = '$id_user'
    ");

    if ($update) {

        $pesan = "Profil berhasil diperbarui.";
        $tipe = "success";

    } else {

        $pesan = "Profil gagal diperbarui.";
        $tipe = "danger";
    }
}


/* AMBIL DATA TERBARU */

$q_nasabah = mysqli_query($conn, "
    SELECT 
        nasabah.*,
        users.username
    FROM nasabah
    JOIN users
        ON nasabah.id_user = users.id_user
    WHERE nasabah.id_user = '$id_user'
");

$nasabah = mysqli_fetch_assoc($q_nasabah);

$nama = $nasabah['nama'];
$saldo = $nasabah['saldo'];
$username = $nasabah['username'];

$inisial = strtoupper(substr($nama, 0, 1));

?>

<!DOCTYPE html>
<html lang="id">

<head>

    <meta charset="UTF-8">

    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Profil Saya — ECOBANK</title>

    <link href="https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;500;600;700&family=Playfair+Display:wght@600;700&display=swap" rel="stylesheet">

    <link rel="stylesheet" href="style.css">

</head>

<body>


<div class="sidebar">

    <div class="logo">
        ECO<span>BANK</span>
    </div>

    <div class="sidebar-subtitle">
        Membangun Kepedulian, Menciptakan Perubahan.
    </div>

    <div class="menu-title">
        MENU UTAMA
    </div>

    <a href="dashboard.php" class="nav-link">
        Dashboard
    </a>

    <a href="setoran.php" class="nav-link">
        Riwayat Setoran
    </a>

    <a href="penarikan.php" class="nav-link">
        Penarikan
    </a>

    <a href="harga.php" class="nav-link">
        Harga Sampah
    </a>

    <a href="profil.php" class="nav-link active">
        Profil Saya
    </a>

    <a href="../logout.php" class="logout">
        Keluar
    </a>

</div>


<div class="main">


    <div class="page-header">

        <div>

            <h1>Profil Saya</h1>

            <p>
                Kelola informasi akun ECOBANK kamu.
            </p>

        </div>

        <div class="user-badge">
            <?= htmlspecialchars($nama) ?>
        </div>

    </div>


    <?php if ($pesan): ?>

        <div class="alert alert-<?= $tipe ?>">
            <?= htmlspecialchars($pesan) ?>
        </div>

    <?php endif; ?>


    <div class="profile-layout">


        <!-- PROFILE SUMMARY -->

        <div class="profile-summary">

            <div class="profile-avatar">
                <?= htmlspecialchars($inisial) ?>
            </div>

            <h3>
                <?= htmlspecialchars($nama) ?>
            </h3>

            <p>
                @<?= htmlspecialchars($username) ?>
            </p>


            <div class="balance-box">

                <div class="balance-label">
                    Saldo Saat Ini
                </div>

                <div class="balance-value">
                    Rp <?= number_format($saldo, 0, ',', '.') ?>
                </div>

            </div>

        </div>


        <!-- FORM -->

        <div class="card-box" style="margin-bottom:0;">

            <div class="card-title">
                Informasi Pribadi
            </div>

            <div class="card-subtitle">
                Perbarui informasi pribadi yang tersimpan di akun kamu.
            </div>


            <form method="POST">


                <div class="form-group">

                    <label class="form-label">
                        Username
                    </label>

                    <input
                        type="text"
                        class="form-control"
                        value="<?= htmlspecialchars($username) ?>"
                        readonly
                        style="background:#f1f4f1;"
                    >

                </div>


                <div class="form-group">

                    <label class="form-label">
                        Nama Lengkap
                    </label>

                    <input
                        type="text"
                        name="nama"
                        class="form-control"
                        value="<?= htmlspecialchars($nama) ?>"
                        required
                    >

                </div>


                <div class="form-group">

                    <label class="form-label">
                        Alamat
                    </label>

                    <textarea
                        name="alamat"
                        class="form-control"
                        required
                    ><?= htmlspecialchars($nasabah['alamat']) ?></textarea>

                </div>


                <div class="form-group">

                    <label class="form-label">
                        No. HP
                    </label>

                    <input
                        type="text"
                        name="no_hp"
                        class="form-control"
                        value="<?= htmlspecialchars($nasabah['no_hp']) ?>"
                        required
                    >

                </div>


                <button
                    type="submit"
                    name="simpan"
                    class="btn-primary"
                >
                    Simpan Perubahan
                </button>

            </form>

        </div>


    </div>


</div>

</body>
</html>