<?php
session_start();
include "../config/koneksi.php";

if (!isset($_SESSION['id_user']) || $_SESSION['role'] != 'nasabah') {
    header("Location: ../login.php");
    exit;
}

$id_user = $_SESSION['id_user'];

$q_nasabah = mysqli_query($conn, "
    SELECT * FROM nasabah
    WHERE id_user = '$id_user'
");

$nasabah = mysqli_fetch_assoc($q_nasabah);

$q_harga = mysqli_query($conn, "
    SELECT *
    FROM jenis_sampah
    ORDER BY nama_sampah ASC
");

?>

<!DOCTYPE html>
<html lang="id">

<head>

    <meta charset="UTF-8">

    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Harga Sampah — ECOBANK</title>

    <link href="https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;500;600;700&family=Playfair+Display:wght@600;700&display=swap" rel="stylesheet">

    <link rel="stylesheet" href="style.css">

</head>

<body>


<div class="sidebar">

    <div class="logo">
        ECO<span>BANK</span>
    </div>

    <div class="sidebar-subtitle">
        Membangun Kepedulian, Menciptakan Perubahan.
    </div>

    <div class="menu-title">
        MENU UTAMA
    </div>

    <a href="dashboard.php" class="nav-link">
        Dashboard
    </a>

    <a href="setoran.php" class="nav-link">
        Riwayat Setoran
    </a>

    <a href="penarikan.php" class="nav-link">
        Penarikan
    </a>

    <a href="harga.php" class="nav-link active">
        Harga Sampah
    </a>

    <a href="profil.php" class="nav-link">
        Profil Saya
    </a>

    <a href="../logout.php" class="logout">
        Keluar
    </a>

</div>


<div class="main">


    <div class="page-header">

        <div>

            <h1>Harga Sampah</h1>

            <p>
                Lihat harga sampah yang berlaku di ECOBANK.
            </p>

        </div>

        <div class="user-badge">
            <?= htmlspecialchars($nasabah['nama']) ?>
        </div>

    </div>


    <div class="card-box">

        <div class="card-title">
            Daftar Harga Sampah
        </div>

        <div class="card-subtitle">
            Harga dihitung berdasarkan berat sampah yang kamu setorkan.
        </div>


        <div class="price-grid">

            <?php

            if (mysqli_num_rows($q_harga) > 0):

                while ($row = mysqli_fetch_assoc($q_harga)):

            ?>

                <div class="price-card">

                    <div class="price-name">
                        <?= htmlspecialchars($row['nama_sampah']) ?>
                    </div>

                    <div class="price-value">
                        Rp <?= number_format($row['harga_per_kg'], 0, ',', '.') ?>
                    </div>

                    <div class="price-unit">
                        per kilogram
                    </div>

                </div>

            <?php

                endwhile;

            else:

            ?>

                <div style="grid-column:1/-1; text-align:center; padding:40px; color:#87938d;">
                    Belum ada data harga sampah.
                </div>

            <?php endif; ?>

        </div>

    </div>


    <div class="card-box">

        <div class="card-title">
            Cara Perhitungan
        </div>

        <div class="card-subtitle">
            Nilai setoran dihitung berdasarkan harga per kilogram.
        </div>


        <div class="info-grid">

            <div class="info-item">

                <strong>
                    1. Pilih Jenis Sampah
                </strong>

                <span>
                    Setiap jenis sampah memiliki harga yang berbeda.
                </span>

            </div>


            <div class="info-item">

                <strong>
                    2. Timbang Sampah
                </strong>

                <span>
                    Berat sampah dicatat dalam satuan kilogram.
                </span>

            </div>


            <div class="info-item">

                <strong>
                    3. Saldo Bertambah
                </strong>

                <span>
                    Nilai setoran otomatis masuk ke saldo nasabah.
                </span>

            </div>

        </div>

    </div>


</div>

</body>
</html>