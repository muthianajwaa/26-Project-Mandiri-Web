<?php
session_start();
include "../config/koneksi.php";

if (!isset($_SESSION['id_user']) || $_SESSION['role'] != 'nasabah') {
    header("Location: ../login.php");
    exit;
}

$id_user = $_SESSION['id_user'];
$pesan = "";
$tipe = "";

$q_nasabah = mysqli_query($conn, "
    SELECT * FROM nasabah
    WHERE id_user = '$id_user'
");

$nasabah = mysqli_fetch_assoc($q_nasabah);

$id_nasabah = $nasabah['id_nasabah'];
$saldo = $nasabah['saldo'];


/* AJUKAN PENARIKAN */

if (isset($_POST['ajukan'])) {

    $jumlah = (float) $_POST['jumlah'];
    $tanggal = date('Y-m-d');

    if ($jumlah <= 0) {

        $pesan = "Jumlah penarikan harus lebih dari 0.";
        $tipe = "danger";

    } elseif ($jumlah > $saldo) {

        $pesan = "Jumlah penarikan melebihi saldo yang tersedia.";
        $tipe = "danger";

    } else {

        $query = mysqli_query($conn, "
            INSERT INTO penarikan
            (id_nasabah, tanggal, jumlah, status)
            VALUES
            ('$id_nasabah', '$tanggal', '$jumlah', 'Pending')
        ");

        if ($query) {

            $pesan = "Pengajuan penarikan berhasil dikirim.";
            $tipe = "success";

        } else {

            $pesan = "Pengajuan gagal: " . mysqli_error($conn);
            $tipe = "danger";
        }
    }
}


/* REFRESH SALDO */

$q_nasabah = mysqli_query($conn, "
    SELECT * FROM nasabah
    WHERE id_user = '$id_user'
");

$nasabah = mysqli_fetch_assoc($q_nasabah);
$saldo = $nasabah['saldo'];


/* RIWAYAT */

$q_penarikan = mysqli_query($conn, "
    SELECT *
    FROM penarikan
    WHERE id_nasabah = '$id_nasabah'
    ORDER BY id_penarikan DESC
");

?>

<!DOCTYPE html>
<html lang="id">

<head>

    <meta charset="UTF-8">

    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Penarikan Saldo — ECOBANK</title>

    <link href="https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;500;600;700&family=Playfair+Display:wght@600;700&display=swap" rel="stylesheet">

    <link rel="stylesheet" href="style.css">

</head>

<body>


<div class="sidebar">

    <div class="logo">
        ECO<span>BANK</span>
    </div>

    <div class="sidebar-subtitle">
        Membangun Kepedulian, Menciptakan Perubahan.
    </div>

    <div class="menu-title">
        MENU UTAMA
    </div>

    <a href="dashboard.php" class="nav-link">
        Dashboard
    </a>

    <a href="setoran.php" class="nav-link">
        Riwayat Setoran
    </a>

    <a href="penarikan.php" class="nav-link active">
        Penarikan
    </a>

    <a href="harga.php" class="nav-link">
        Harga Sampah
    </a>

    <a href="profil.php" class="nav-link">
        Profil Saya
    </a>

    <a href="../logout.php" class="logout">
        Keluar
    </a>

</div>


<div class="main">


    <div class="page-header">

        <div>

            <h1>Penarikan Saldo</h1>

            <p>
                Ajukan penarikan saldo dari hasil setoran sampah.
            </p>

        </div>

        <div class="user-badge">
            <?= htmlspecialchars($nasabah['nama']) ?>
        </div>

    </div>


    <?php if ($pesan): ?>

        <div class="alert alert-<?= $tipe ?>">
            <?= htmlspecialchars($pesan) ?>
        </div>

    <?php endif; ?>


    <div class="stats">

        <div class="stat-card">

            <div class="stat-icon">
                Rp
            </div>

            <div class="stat-number">
                Rp <?= number_format($saldo, 0, ',', '.') ?>
            </div>

            <div class="stat-label">
                Saldo Tersedia
            </div>

        </div>


        <div class="stat-card">

            <div class="stat-icon">
                P
            </div>

            <div class="stat-number">
                <?= mysqli_num_rows($q_penarikan) ?>
            </div>

            <div class="stat-label">
                Total Pengajuan
            </div>

        </div>


        <div class="stat-card">

            <div class="stat-icon">
                !
            </div>

            <div class="stat-number">
                Pending
            </div>

            <div class="stat-label">
                Menunggu persetujuan admin
            </div>

        </div>

    </div>


    <div class="card-box">

        <div class="card-title">
            Ajukan Penarikan
        </div>

        <div class="card-subtitle">
            Masukkan nominal saldo yang ingin kamu tarik.
        </div>


        <form method="POST">

            <div class="form-group">

                <label class="form-label">
                    Jumlah Penarikan
                </label>

                <input
                    type="number"
                    name="jumlah"
                    class="form-control"
                    min="1"
                    max="<?= $saldo ?>"
                    placeholder="Contoh: 50000"
                    required
                >

            </div>


            <button
                type="submit"
                name="ajukan"
                class="btn-primary"
            >
                Ajukan Penarikan
            </button>

        </form>

    </div>


    <div class="card-box">

        <div class="card-title">
            Riwayat Penarikan
        </div>

        <div class="card-subtitle">
            Pantau status pengajuan penarikan saldo kamu.
        </div>


        <div class="table-wrap">

            <table>

                <thead>

                    <tr>
                        <th>No</th>
                        <th>Tanggal</th>
                        <th>Jumlah</th>
                        <th>Status</th>
                    </tr>

                </thead>

                <tbody>

                <?php

                $no = 1;

                if (mysqli_num_rows($q_penarikan) > 0):

                    while ($row = mysqli_fetch_assoc($q_penarikan)):

                        if ($row['status'] == 'Pending') {
                            $class = 'pending';
                        } elseif ($row['status'] == 'Disetujui') {
                            $class = 'approved';
                        } else {
                            $class = 'rejected';
                        }

                ?>

                    <tr>

                        <td>
                            <?= $no++ ?>
                        </td>

                        <td>
                            <?= date('d/m/Y', strtotime($row['tanggal'])) ?>
                        </td>

                        <td>
                            <strong>
                                Rp <?= number_format($row['jumlah'], 0, ',', '.') ?>
                            </strong>
                        </td>

                        <td>

                            <span class="badge-status <?= $class ?>">
                                <?= htmlspecialchars($row['status']) ?>
                            </span>

                        </td>

                    </tr>

                <?php

                    endwhile;

                else:

                ?>

                    <tr>

                        <td colspan="4" style="text-align:center; padding:40px; color:#87938d;">
                            Belum ada pengajuan penarikan.
                        </td>

                    </tr>

                <?php endif; ?>

                </tbody>

            </table>

        </div>

    </div>


</div>

</body>
</html>