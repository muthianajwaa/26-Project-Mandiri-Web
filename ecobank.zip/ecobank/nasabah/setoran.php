<?php
session_start();
include "../config/koneksi.php";

if (!isset($_SESSION['id_user']) || $_SESSION['role'] != 'nasabah') {
    header("Location: ../login.php");
    exit;
}

$id_user = $_SESSION['id_user'];

$q_nasabah = mysqli_query($conn, "
    SELECT * FROM nasabah
    WHERE id_user = '$id_user'
");

$nasabah = mysqli_fetch_assoc($q_nasabah);
$id_nasabah = $nasabah['id_nasabah'];

$q_total = mysqli_query($conn, "
    SELECT 
        COALESCE(SUM(berat),0) AS berat,
        COALESCE(SUM(total_harga),0) AS total
    FROM setoran
    WHERE id_nasabah = '$id_nasabah'
");

$total = mysqli_fetch_assoc($q_total);

$q_setoran = mysqli_query($conn, "
    SELECT 
        setoran.*,
        jenis_sampah.nama_sampah,
        jenis_sampah.harga_per_kg
    FROM setoran
    JOIN jenis_sampah
        ON setoran.id_sampah = jenis_sampah.id_sampah
    WHERE setoran.id_nasabah = '$id_nasabah'
    ORDER BY setoran.id_setoran DESC
");
?>

<!DOCTYPE html>
<html lang="id">

<head>

    <meta charset="UTF-8">

    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Riwayat Setoran — ECOBANK</title>

    <link href="https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;500;600;700&family=Playfair+Display:wght@600;700&display=swap" rel="stylesheet">

    <link rel="stylesheet" href="style.css">

</head>

<body>


<div class="sidebar">

    <div class="logo">
        ECO<span>BANK</span>
    </div>

    <div class="sidebar-subtitle">
        Membangun Kepedulian, Menciptakan Perubahan.
    </div>

    <div class="menu-title">
        MENU UTAMA
    </div>

    <a href="dashboard.php" class="nav-link">
        Dashboard
    </a>

    <a href="setoran.php" class="nav-link active">
        Riwayat Setoran
    </a>

    <a href="penarikan.php" class="nav-link">
        Penarikan
    </a>

    <a href="harga.php" class="nav-link">
        Harga Sampah
    </a>

    <a href="profil.php" class="nav-link">
        Profil Saya
    </a>

    <a href="../logout.php" class="logout">
        Keluar
    </a>

</div>


<div class="main">


    <div class="page-header">

        <div>

            <h1>Riwayat Setoran</h1>

            <p>
                Lihat seluruh transaksi setoran sampah kamu.
            </p>

        </div>

        <div class="user-badge">
            <?= htmlspecialchars($nasabah['nama']) ?>
        </div>

    </div>


    <div class="stats">

        <div class="stat-card">

            <div class="stat-icon">
                KG
            </div>

            <div class="stat-number">
                <?= number_format($total['berat'], 2, ',', '.') ?> kg
            </div>

            <div class="stat-label">
                Total Sampah Disetor
            </div>

        </div>


        <div class="stat-card">

            <div class="stat-icon">
                Rp
            </div>

            <div class="stat-number">
                Rp <?= number_format($total['total'], 0, ',', '.') ?>
            </div>

            <div class="stat-label">
                Total Nilai Setoran
            </div>

        </div>


        <div class="stat-card">

            <div class="stat-icon">
                S
            </div>

            <div class="stat-number">
                <?= mysqli_num_rows($q_setoran) ?>
            </div>

            <div class="stat-label">
                Jumlah Transaksi
            </div>

        </div>

    </div>


    <div class="card-box">

        <div class="card-title">
            Semua Riwayat Setoran
        </div>

        <div class="card-subtitle">
            Daftar transaksi sampah yang telah dicatat oleh petugas ECOBANK.
        </div>


        <div class="table-wrap">

            <table>

                <thead>

                    <tr>
                        <th>No</th>
                        <th>Tanggal</th>
                        <th>Jenis Sampah</th>
                        <th>Harga / Kg</th>
                        <th>Berat</th>
                        <th>Total</th>
                    </tr>

                </thead>

                <tbody>

                <?php

                $no = 1;

                if (mysqli_num_rows($q_setoran) > 0):

                    while ($row = mysqli_fetch_assoc($q_setoran)):

                ?>

                    <tr>

                        <td><?= $no++ ?></td>

                        <td>
                            <?= date('d/m/Y', strtotime($row['tanggal'])) ?>
                        </td>

                        <td>
                            <strong>
                                <?= htmlspecialchars($row['nama_sampah']) ?>
                            </strong>
                        </td>

                        <td>
                            Rp <?= number_format($row['harga_per_kg'], 0, ',', '.') ?>
                        </td>

                        <td>
                            <?= number_format($row['berat'], 2, ',', '.') ?> kg
                        </td>

                        <td>
                            <strong>
                                Rp <?= number_format($row['total_harga'], 0, ',', '.') ?>
                            </strong>
                        </td>

                    </tr>

                <?php

                    endwhile;

                else:

                ?>

                    <tr>

                        <td colspan="6" style="text-align:center; padding:40px; color:#87938d;">
                            Belum ada transaksi setoran.
                        </td>

                    </tr>

                <?php endif; ?>

                </tbody>

            </table>

        </div>

    </div>

</div>

</body>
</html>