<?php
session_start();
include "../config/koneksi.php";

if (!isset($_SESSION['id_user']) || $_SESSION['role'] != 'nasabah') {
    header("Location: ../login.php");
    exit;
}

$id_user = $_SESSION['id_user'];

/* DATA NASABAH */
$q_nasabah = mysqli_query($conn, "
    SELECT *
    FROM nasabah
    WHERE id_user = '$id_user'
");

$nasabah = mysqli_fetch_assoc($q_nasabah);

if (!$nasabah) {
    die("Data nasabah tidak ditemukan.");
}

$id_nasabah = $nasabah['id_nasabah'];


/* TOTAL SAMPAH */
$q_berat = mysqli_query($conn, "
    SELECT COALESCE(SUM(berat), 0) AS total_berat
    FROM setoran
    WHERE id_nasabah = '$id_nasabah'
");

$data_berat = mysqli_fetch_assoc($q_berat);


/* TOTAL SETORAN */
$q_setoran = mysqli_query($conn, "
    SELECT COUNT(*) AS total_setoran
    FROM setoran
    WHERE id_nasabah = '$id_nasabah'
");

$data_setoran = mysqli_fetch_assoc($q_setoran);


/* TOTAL PENARIKAN */
$q_penarikan = mysqli_query($conn, "
    SELECT COALESCE(SUM(jumlah), 0) AS total_penarikan
    FROM penarikan
    WHERE id_nasabah = '$id_nasabah'
    AND status = 'Disetujui'
");

$data_penarikan = mysqli_fetch_assoc($q_penarikan);


/* RIWAYAT SETORAN TERBARU */
$q_riwayat = mysqli_query($conn, "
    SELECT
        setoran.*,
        jenis_sampah.nama_sampah
    FROM setoran
    JOIN jenis_sampah
        ON setoran.id_sampah = jenis_sampah.id_sampah
    WHERE setoran.id_nasabah = '$id_nasabah'
    ORDER BY setoran.id_setoran DESC
    LIMIT 5
");
?>

<!DOCTYPE html>
<html lang="id">

<head>

    <meta charset="UTF-8">

    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Dashboard — ECOBANK</title>

    <link
        href="https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;500;600;700&family=Playfair+Display:wght@600;700&display=swap"
        rel="stylesheet"
    >

    <link rel="stylesheet" href="style.css">

</head>

<body>


<!-- ================= SIDEBAR ================= -->

<div class="sidebar">

    <div class="logo">
        ECO<span>BANK</span>
    </div>

    <div class="sidebar-subtitle">
        Membangun Kepedulian, Menciptakan Perubahan.
    </div>

    <div class="menu-title">
        MENU UTAMA
    </div>


    <a href="dashboard.php" class="nav-link active">
        Dashboard
    </a>

    <a href="setoran.php" class="nav-link">
        Riwayat Setoran
    </a>

    <a href="penarikan.php" class="nav-link">
        Penarikan
    </a>

    <a href="harga.php" class="nav-link">
        Harga Sampah
    </a>

    <a href="profil.php" class="nav-link">
        Profil Saya
    </a>


    <a href="../logout.php" class="logout">
        Keluar
    </a>

</div>


<!-- ================= MAIN ================= -->

<div class="main">


    <!-- HEADER -->

    <div class="page-header">

        <div>

            <h1>
                Selamat datang kembali,
                <?= htmlspecialchars($nasabah['nama']) ?> 👋
            </h1>

            <p>
                Senang melihat kamu kembali di dashboard ECOBANK.
            </p>

        </div>


        <div class="user-badge">

            <?= htmlspecialchars($nasabah['nama']) ?>

        </div>

    </div>


    <!-- ================= STATISTIK ================= -->

    <div class="stats">


        <!-- SALDO -->

        <div class="stat-card">

            <div class="stat-icon">
                Rp
            </div>

            <div class="stat-number">
                Rp <?= number_format($nasabah['saldo'], 0, ',', '.') ?>
            </div>

            <div class="stat-label">
                Saldo Saya
            </div>

        </div>


        <!-- SAMPAH -->

        <div class="stat-card">

            <div class="stat-icon">
                KG
            </div>

            <div class="stat-number">
                <?= number_format($data_berat['total_berat'], 2, ',', '.') ?> kg
            </div>

            <div class="stat-label">
                Sampah Disetor
            </div>

        </div>


        <!-- TOTAL SETORAN -->

        <div class="stat-card">

            <div class="stat-icon">
                S
            </div>

            <div class="stat-number">
                <?= $data_setoran['total_setoran'] ?>
            </div>

            <div class="stat-label">
                Total Setoran
            </div>

        </div>


        <!-- TOTAL PENARIKAN -->

        <div class="stat-card">

            <div class="stat-icon">
                P
            </div>

            <div class="stat-number">
                Rp <?= number_format($data_penarikan['total_penarikan'], 0, ',', '.') ?>
            </div>

            <div class="stat-label">
                Total Penarikan
            </div>

        </div>

    </div>


    <!-- ================= RIWAYAT ================= -->

    <div class="card-box">

        <div class="card-title">
            Riwayat Setoran Terbaru
        </div>

        <div class="card-subtitle">
            Data setoran sampah yang terakhir tercatat.
        </div>


        <div class="table-wrap">

            <table>

                <thead>

                    <tr>

                        <th>No</th>
                        <th>Tanggal</th>
                        <th>Jenis Sampah</th>
                        <th>Berat</th>
                        <th>Total</th>

                    </tr>

                </thead>


                <tbody>

                <?php

                $no = 1;

                if (mysqli_num_rows($q_riwayat) > 0):

                    while ($row = mysqli_fetch_assoc($q_riwayat)):

                ?>

                    <tr>

                        <td>
                            <?= $no++ ?>
                        </td>

                        <td>
                            <?= date('d/m/Y', strtotime($row['tanggal'])) ?>
                        </td>

                        <td>

                            <strong>
                                <?= htmlspecialchars($row['nama_sampah']) ?>
                            </strong>

                        </td>

                        <td>
                            <?= number_format($row['berat'], 2, ',', '.') ?> kg
                        </td>

                        <td>

                            <strong>
                                Rp <?= number_format($row['total_harga'], 0, ',', '.') ?>
                            </strong>

                        </td>

                    </tr>

                <?php

                    endwhile;

                else:

                ?>

                    <tr>

                        <td
                            colspan="5"
                            style="text-align:center; padding:40px; color:#87938d;"
                        >
                            Belum ada riwayat setoran.

                        </td>

                    </tr>

                <?php endif; ?>

                </tbody>

            </table>

        </div>

    </div>


    <!-- ================= AKSES CEPAT ================= -->

    <div class="card-box">

        <div class="card-title">
            Akses Cepat
        </div>

        <div class="card-subtitle">
            Akses beberapa fitur ECOBANK dengan cepat.
        </div>


        <div class="info-grid">


            <a
                href="setoran.php"
                class="info-item"
                style="text-decoration:none;"
            >

                <strong>
                    Riwayat Setoran
                </strong>

                <span>
                    Lihat seluruh transaksi setoran sampah kamu.
                </span>

            </a>


            <a
                href="penarikan.php"
                class="info-item"
                style="text-decoration:none;"
            >

                <strong>
                    Penarikan Saldo
                </strong>

                <span>
                    Ajukan penarikan saldo dari tabungan sampah.
                </span>

            </a>


            <a
                href="harga.php"
                class="info-item"
                style="text-decoration:none;"
            >

                <strong>
                    Harga Sampah
                </strong>

                <span>
                    Lihat daftar harga sampah yang berlaku.
                </span>

            </a>


        </div>

    </div>


</div>

</body>

</html>