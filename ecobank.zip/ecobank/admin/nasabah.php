<?php
session_start();
include "../config/koneksi.php";

if (!isset($_SESSION['id_user']) || $_SESSION['role'] != 'admin') {
    header("Location: ../login.php");
    exit;
}

/* TAMBAH DATA */
if (isset($_POST['simpan'])) {

    $nama = mysqli_real_escape_string($conn, $_POST['nama']);
    $alamat = mysqli_real_escape_string($conn, $_POST['alamat']);
    $no_hp = mysqli_real_escape_string($conn, $_POST['no_hp']);
    $username = mysqli_real_escape_string($conn, $_POST['username']);
    $password = password_hash($_POST['password'], PASSWORD_DEFAULT);

    mysqli_query($conn, "INSERT INTO users (username, password, role)
                         VALUES ('$username', '$password', 'nasabah')");

    $id_user = mysqli_insert_id($conn);

    mysqli_query($conn, "INSERT INTO nasabah
                         (id_user, nama, alamat, no_hp, saldo)
                         VALUES ('$id_user', '$nama', '$alamat', '$no_hp', 0)");

    header("Location: nasabah.php");
    exit;
}

/* HAPUS DATA */
if (isset($_GET['hapus'])) {

    $id = intval($_GET['hapus']);

    $data = mysqli_query($conn, "SELECT id_user FROM nasabah WHERE id_nasabah='$id'");
    $user = mysqli_fetch_assoc($data);

    if ($user) {
        mysqli_query($conn, "DELETE FROM users WHERE id_user='".$user['id_user']."'");
    }

    header("Location: nasabah.php");
    exit;
}

/* AMBIL DATA */
$data_nasabah = mysqli_query(
    $conn,
    "SELECT nasabah.*, users.username
     FROM nasabah
     JOIN users ON nasabah.id_user = users.id_user
     ORDER BY nasabah.id_nasabah DESC"
);

?>

<!DOCTYPE html>
<html lang="id">

<head>

<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<title>Data Nasabah — ECOBANK</title>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">

<link href="https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;500;600;700&family=Playfair+Display:wght@600;700&display=swap" rel="stylesheet">

<style>

body {
    margin: 0;
    background: #f5f7f2;
    font-family: 'DM Sans', sans-serif;
    color: #193c2e;
}

.sidebar {
    position: fixed;
    width: 245px;
    height: 100vh;
    background: #153f30;
    padding: 30px 20px;
    color: white;
}

.logo {
    font-size: 25px;
    font-weight: 700;
    letter-spacing: 1px;
    padding: 0 15px;
    margin-bottom: 45px;
}

.logo span {
    color: #91bd73;
}

.menu-title {
    color: #91a99d;
    font-size: 12px;
    text-transform: uppercase;
    letter-spacing: 1px;
    padding: 0 15px;
    margin-bottom: 12px;
}

.menu a {
    display: block;
    color: #c9d8d1;
    text-decoration: none;
    padding: 13px 15px;
    border-radius: 12px;
    margin-bottom: 5px;
}

.menu a:hover,
.menu a.active {
    background: #285d47;
    color: white;
}

.logout {
    position: absolute;
    bottom: 25px;
    left: 20px;
    right: 20px;
}

.logout a {
    color: #d7aaa3;
}

.content {
    margin-left: 245px;
    padding: 35px 45px;
}

.page-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 30px;
}

.page-header h1 {
    font-family: 'Playfair Display', serif;
    font-size: 34px;
    margin: 0;
}

.page-header p {
    color: #78877f;
    margin-top: 5px;
}

.btn-tambah {
    background: #174c38;
    color: white;
    border: none;
    border-radius: 12px;
    padding: 12px 20px;
    font-weight: 600;
}

.btn-tambah:hover {
    background: #0f382a;
    color: white;
}

.card-custom {
    background: white;
    border: 1px solid #e8ede7;
    border-radius: 22px;
    padding: 28px;
}

.table {
    vertical-align: middle;
}

.table thead th {
    color: #718078;
    font-size: 13px;
    font-weight: 600;
    border-bottom: 1px solid #e5ebe4;
}

.table tbody td {
    padding-top: 18px;
    padding-bottom: 18px;
}

.badge-saldo {
    background: #e5f0df;
    color: #347050;
    padding: 7px 11px;
    border-radius: 20px;
    font-weight: 600;
}

.btn-edit {
    color: #47755e;
    text-decoration: none;
    font-weight: 600;
}

.btn-hapus {
    color: #b45d52;
    text-decoration: none;
    font-weight: 600;
}

</style>

</head>

<body>


<!-- SIDEBAR -->

<div class="sidebar">

    <div class="logo">
        ECO<span>BANK</span>
    </div>

    <div class="menu-title">
        Menu Utama
    </div>

    <div class="menu">

        <a href="dashboard.php">
            Dashboard
        </a>

        <a href="nasabah.php" class="active">
            Data Nasabah
        </a>

        <a href="jenis_sampah.php">
            Jenis Sampah
        </a>

        <a href="setoran.php">
            Setoran Sampah
        </a>

        <a href="penarikan.php">
            Penarikan
        </a>

        <a href="laporan.php">
            Laporan
        </a>

    </div>

    <div class="logout">

        <a href="../logout.php">
            Keluar
        </a>

    </div>

</div>


<!-- CONTENT -->

<div class="content">

    <div class="page-header">

        <div>

            <h1>Data Nasabah</h1>

            <p>
                Kelola data pengguna yang terdaftar sebagai nasabah ECOBANK.
            </p>

        </div>

        <button
            class="btn-tambah"
            data-bs-toggle="modal"
            data-bs-target="#modalTambah"
        >
            + Tambah Nasabah
        </button>

    </div>


    <div class="card-custom">

        <div class="table-responsive">

            <table class="table">

                <thead>

                    <tr>
                        <th>No</th>
                        <th>Nama</th>
                        <th>Username</th>
                        <th>No. HP</th>
                        <th>Saldo</th>
                        <th>Aksi</th>
                    </tr>

                </thead>

                <tbody>

                <?php
                $no = 1;

                while ($row = mysqli_fetch_assoc($data_nasabah)):
                ?>

                    <tr>

                        <td><?= $no++ ?></td>

                        <td>
                            <strong>
                                <?= htmlspecialchars($row['nama']) ?>
                            </strong>
                        </td>

                        <td>
                            <?= htmlspecialchars($row['username']) ?>
                        </td>

                        <td>
                            <?= htmlspecialchars($row['no_hp']) ?>
                        </td>

                        <td>

                            <span class="badge-saldo">
                                Rp <?= number_format($row['saldo'], 0, ',', '.') ?>
                            </span>

                        </td>

                        <td>

                            <a
                                href="#"
                                class="btn-edit me-3"
                            >
                                Edit
                            </a>

                            <a
                                href="nasabah.php?hapus=<?= $row['id_nasabah'] ?>"
                                class="btn-hapus"
                                onclick="return confirm('Yakin ingin menghapus nasabah ini?')"
                            >
                                Hapus
                            </a>

                        </td>

                    </tr>

                <?php endwhile; ?>

                </tbody>

            </table>

        </div>

    </div>

</div>


<!-- MODAL TAMBAH -->

<div class="modal fade" id="modalTambah" tabindex="-1">

    <div class="modal-dialog modal-dialog-centered">

        <div class="modal-content">

            <form method="POST">

                <div class="modal-header">

                    <h5 class="modal-title">
                        Tambah Nasabah
                    </h5>

                    <button
                        type="button"
                        class="btn-close"
                        data-bs-dismiss="modal"
                    ></button>

                </div>


                <div class="modal-body">

                    <div class="mb-3">

                        <label class="form-label">
                            Nama Lengkap
                        </label>

                        <input
                            type="text"
                            name="nama"
                            class="form-control"
                            required
                        >

                    </div>


                    <div class="mb-3">

                        <label class="form-label">
                            Username
                        </label>

                        <input
                            type="text"
                            name="username"
                            class="form-control"
                            required
                        >

                    </div>


                    <div class="mb-3">

                        <label class="form-label">
                            Password
                        </label>

                        <input
                            type="password"
                            name="password"
                            class="form-control"
                            required
                        >

                    </div>


                    <div class="mb-3">

                        <label class="form-label">
                            No. HP
                        </label>

                        <input
                            type="text"
                            name="no_hp"
                            class="form-control"
                        >

                    </div>


                    <div class="mb-3">

                        <label class="form-label">
                            Alamat
                        </label>

                        <textarea
                            name="alamat"
                            class="form-control"
                            rows="3"
                        ></textarea>

                    </div>

                </div>


                <div class="modal-footer">

                    <button
                        type="button"
                        class="btn btn-light"
                        data-bs-dismiss="modal"
                    >
                        Batal
                    </button>

                    <button
                        type="submit"
                        name="simpan"
                        class="btn btn-success"
                    >
                        Simpan Nasabah
                    </button>

                </div>

            </form>

        </div>

    </div>

</div>


<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>

</body>
</html>