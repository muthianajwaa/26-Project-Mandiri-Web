<?php
session_start();
include "../config/koneksi.php";

if (!isset($_SESSION['id_user']) || $_SESSION['role'] != 'admin') {
    header("Location: ../login.php");
    exit;
}

/* TOTAL SETORAN */
$q1 = mysqli_query($conn, "
    SELECT 
        COUNT(*) AS jumlah,
        COALESCE(SUM(berat),0) AS berat,
        COALESCE(SUM(total_harga),0) AS nilai
    FROM setoran
");

$stat_setoran = mysqli_fetch_assoc($q1);


/* TOTAL PENARIKAN */
$q2 = mysqli_query($conn, "
    SELECT 
        COUNT(*) AS jumlah,
        COALESCE(SUM(jumlah),0) AS nilai
    FROM penarikan
    WHERE status = 'Disetujui'
");

$stat_penarikan = mysqli_fetch_assoc($q2);


/* DATA SETORAN */
$setoran = mysqli_query($conn, "
    SELECT
        setoran.*,
        nasabah.nama,
        jenis_sampah.nama_sampah
    FROM setoran
    JOIN nasabah
        ON setoran.id_nasabah = nasabah.id_nasabah
    JOIN jenis_sampah
        ON setoran.id_sampah = jenis_sampah.id_sampah
    ORDER BY setoran.tanggal DESC
");


/* DATA PENARIKAN */
$penarikan = mysqli_query($conn, "
    SELECT
        penarikan.*,
        nasabah.nama
    FROM penarikan
    JOIN nasabah
        ON penarikan.id_nasabah = nasabah.id_nasabah
    ORDER BY penarikan.tanggal DESC
");
?>

<!DOCTYPE html>
<html lang="id">

<head>

<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<title>Laporan — ECOBANK</title>

<link
href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css"
rel="stylesheet">

<link
href="https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;500;600;700&family=Playfair+Display:wght@600;700&display=swap"
rel="stylesheet">

<style>

body {
    margin: 0;
    background: #f5f7f2;
    font-family: 'DM Sans', sans-serif;
    color: #193c2e;
}

.sidebar {
    position: fixed;
    width: 245px;
    height: 100vh;
    background: #153f30;
    padding: 30px 20px;
    color: white;
}

.logo {
    font-size: 25px;
    font-weight: 700;
    padding: 0 15px;
    margin-bottom: 45px;
}

.logo span {
    color: #91bd73;
}

.menu-title {
    color: #91a99d;
    font-size: 12px;
    text-transform: uppercase;
    padding: 0 15px;
    margin-bottom: 12px;
}

.menu a {
    display: block;
    color: #c9d8d1;
    text-decoration: none;
    padding: 13px 15px;
    border-radius: 12px;
    margin-bottom: 5px;
}

.menu a:hover,
.menu a.active {
    background: #285d47;
    color: white;
}

.logout {
    position: absolute;
    bottom: 25px;
    left: 20px;
    right: 20px;
}

.logout a {
    color: #d7aaa3;
}

.content {
    margin-left: 245px;
    padding: 35px 45px;
}

.page-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 30px;
}

.page-header h1 {
    font-family: 'Playfair Display', serif;
    font-size: 34px;
    margin: 0;
}

.page-header p {
    color: #78877f;
    margin-top: 5px;
}

.btn-print {
    background: #174c38;
    color: white;
    border: none;
    border-radius: 11px;
    padding: 12px 20px;
    font-weight: 600;
}

.stat-card {
    background: white;
    border: 1px solid #e8ede7;
    border-radius: 20px;
    padding: 24px;
    height: 100%;
}

.stat-label {
    color: #78877f;
    font-size: 14px;
}

.stat-number {
    font-size: 27px;
    font-weight: 700;
    margin-top: 8px;
}

.card-custom {
    background: white;
    border: 1px solid #e8ede7;
    border-radius: 22px;
    padding: 28px;
    margin-top: 30px;
}

.table {
    vertical-align: middle;
}

.table thead th {
    color: #718078;
    font-size: 13px;
    border-bottom: 1px solid #e5ebe4;
}

.table tbody td {
    padding-top: 16px;
    padding-bottom: 16px;
}

@media print {

    .sidebar,
    .btn-print,
    .no-print {
        display: none !important;
    }

    .content {
        margin-left: 0;
        padding: 20px;
    }

    body {
        background: white;
    }

    .card-custom,
    .stat-card {
        border: 1px solid #ddd;
        box-shadow: none;
    }

}

</style>

</head>

<body>

<!-- SIDEBAR -->

<div class="sidebar">

    <div class="logo">
        ECO<span>BANK</span>
    </div>

    <div class="menu-title">
        Menu Utama
    </div>

    <div class="menu">

        <a href="dashboard.php">
            Dashboard
        </a>

        <a href="nasabah.php">
            Data Nasabah
        </a>

        <a href="jenis_sampah.php">
            Jenis Sampah
        </a>

        <a href="setoran.php">
            Setoran Sampah
        </a>

        <a href="penarikan.php">
            Penarikan
        </a>

        <a href="laporan.php" class="active">
            Laporan
        </a>

    </div>

    <div class="logout">
        <a href="../logout.php">
            Keluar
        </a>
    </div>

</div>


<!-- CONTENT -->

<div class="content">

    <div class="page-header">

        <div>

            <h1>Laporan ECOBANK</h1>

            <p>
                Ringkasan transaksi dan aktivitas bank sampah.
            </p>

        </div>

        <button
            class="btn-print"
            onclick="window.print()">

            Cetak Laporan

        </button>

    </div>


    <!-- STATISTIK -->

    <div class="row g-4">

        <div class="col-md-4">

            <div class="stat-card">

                <div class="stat-label">
                    Total Setoran
                </div>

                <div class="stat-number">
                    <?= $stat_setoran['jumlah'] ?>
                    transaksi
                </div>

            </div>

        </div>


        <div class="col-md-4">

            <div class="stat-card">

                <div class="stat-label">
                    Sampah Terkumpul
                </div>

                <div class="stat-number">
                    <?= number_format(
                        $stat_setoran['berat'],
                        2,
                        ',',
                        '.'
                    ) ?>
                    Kg
                </div>

            </div>

        </div>


        <div class="col-md-4">

            <div class="stat-card">

                <div class="stat-label">
                    Nilai Penarikan
                </div>

                <div class="stat-number">
                    Rp <?= number_format(
                        $stat_penarikan['nilai'],
                        0,
                        ',',
                        '.'
                    ) ?>
                </div>

            </div>

        </div>

    </div>


    <!-- SETORAN -->

    <div class="card-custom">

        <h5 class="mb-4">
            Laporan Setoran Sampah
        </h5>

        <div class="table-responsive">

            <table class="table">

                <thead>

                    <tr>
                        <th>No</th>
                        <th>Tanggal</th>
                        <th>Nasabah</th>
                        <th>Jenis Sampah</th>
                        <th>Berat</th>
                        <th>Total Nilai</th>
                    </tr>

                </thead>

                <tbody>

                <?php
                $no = 1;

                while ($row = mysqli_fetch_assoc($setoran)):
                ?>

                    <tr>

                        <td><?= $no++ ?></td>

                        <td>
                            <?= date(
                                'd/m/Y',
                                strtotime($row['tanggal'])
                            ) ?>
                        </td>

                        <td>
                            <?= htmlspecialchars($row['nama']) ?>
                        </td>

                        <td>
                            <?= htmlspecialchars(
                                $row['nama_sampah']
                            ) ?>
                        </td>

                        <td>
                            <?= $row['berat'] ?> Kg
                        </td>

                        <td>
                            <strong>
                                Rp <?= number_format(
                                    $row['total_harga'],
                                    0,
                                    ',',
                                    '.'
                                ) ?>
                            </strong>
                        </td>

                    </tr>

                <?php endwhile; ?>

                </tbody>

            </table>

        </div>

    </div>


    <!-- PENARIKAN -->

    <div class="card-custom">

        <h5 class="mb-4">
            Laporan Penarikan Saldo
        </h5>

        <div class="table-responsive">

            <table class="table">

                <thead>

                    <tr>
                        <th>No</th>
                        <th>Tanggal</th>
                        <th>Nasabah</th>
                        <th>Jumlah</th>
                        <th>Status</th>
                    </tr>

                </thead>

                <tbody>

                <?php
                $no = 1;

                while ($row = mysqli_fetch_assoc($penarikan)):
                ?>

                    <tr>

                        <td><?= $no++ ?></td>

                        <td>
                            <?= date(
                                'd/m/Y',
                                strtotime($row['tanggal'])
                            ) ?>
                        </td>

                        <td>
                            <?= htmlspecialchars($row['nama']) ?>
                        </td>

                        <td>
                            Rp <?= number_format(
                                $row['jumlah'],
                                0,
                                ',',
                                '.'
                            ) ?>
                        </td>

                        <td>
                            <?= htmlspecialchars($row['status']) ?>
                        </td>

                    </tr>

                <?php endwhile; ?>

                </tbody>

            </table>

        </div>

    </div>

</div>

</body>
</html>