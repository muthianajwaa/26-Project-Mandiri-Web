<?php
session_start();
include "../config/koneksi.php";

if (!isset($_SESSION['id_user']) || $_SESSION['role'] != 'admin') {
    header("Location: ../login.php");
    exit;
}

$pesan = "";

/* TAMBAH PERMINTAAN PENARIKAN */
if (isset($_POST['simpan'])) {

    $id_nasabah = (int) $_POST['id_nasabah'];
    $tanggal = $_POST['tanggal'];
    $jumlah = (float) $_POST['jumlah'];

    // Cek saldo
    $cek = mysqli_query(
        $conn,
        "SELECT saldo FROM nasabah
         WHERE id_nasabah = $id_nasabah"
    );

    $data = mysqli_fetch_assoc($cek);

    if (!$data) {

        $pesan = "Nasabah tidak ditemukan.";

    } elseif ($jumlah <= 0) {

        $pesan = "Jumlah penarikan tidak valid.";

    } elseif ($jumlah > $data['saldo']) {

        $pesan = "Saldo nasabah tidak mencukupi.";

    } else {

        $simpan = mysqli_query(
            $conn,
            "INSERT INTO penarikan
            (id_nasabah, tanggal, jumlah, status)
            VALUES
            ($id_nasabah, '$tanggal', $jumlah, 'Pending')"
        );

        if ($simpan) {
            $pesan = "Permintaan penarikan berhasil dibuat.";
        } else {
            $pesan = "Gagal menyimpan penarikan.";
        }
    }
}


/* SETUJUI PENARIKAN */
if (isset($_GET['setujui'])) {

    $id = (int) $_GET['setujui'];

    $cek = mysqli_query(
        $conn,
        "SELECT * FROM penarikan
         WHERE id_penarikan = $id
         AND status = 'Pending'"
    );

    $data = mysqli_fetch_assoc($cek);

    if ($data) {

        $id_nasabah = $data['id_nasabah'];
        $jumlah = $data['jumlah'];

        $cek_saldo = mysqli_query(
            $conn,
            "SELECT saldo FROM nasabah
             WHERE id_nasabah = $id_nasabah"
        );

        $saldo = mysqli_fetch_assoc($cek_saldo);

        if ($saldo && $saldo['saldo'] >= $jumlah) {

            mysqli_query(
                $conn,
                "UPDATE nasabah
                 SET saldo = saldo - $jumlah
                 WHERE id_nasabah = $id_nasabah"
            );

            mysqli_query(
                $conn,
                "UPDATE penarikan
                 SET status = 'Disetujui'
                 WHERE id_penarikan = $id"
            );
        }
    }

    header("Location: penarikan.php");
    exit;
}


/* TOLAK */
if (isset($_GET['tolak'])) {

    $id = (int) $_GET['tolak'];

    mysqli_query(
        $conn,
        "UPDATE penarikan
         SET status = 'Ditolak'
         WHERE id_penarikan = $id
         AND status = 'Pending'"
    );

    header("Location: penarikan.php");
    exit;
}


/* DATA NASABAH */
$nasabah = mysqli_query(
    $conn,
    "SELECT id_nasabah, nama, saldo
     FROM nasabah
     ORDER BY nama ASC"
);


/* DATA PENARIKAN */
$data_penarikan = mysqli_query(
    $conn,
    "SELECT
        penarikan.*,
        nasabah.nama
     FROM penarikan
     JOIN nasabah
        ON penarikan.id_nasabah = nasabah.id_nasabah
     ORDER BY penarikan.id_penarikan DESC"
);

?>

<!DOCTYPE html>
<html lang="id">

<head>

<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<title>Penarikan — ECOBANK</title>

<link
href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css"
rel="stylesheet">

<link
href="https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;500;600;700&family=Playfair+Display:wght@600;700&display=swap"
rel="stylesheet">

<style>

body {
    margin: 0;
    background: #f5f7f2;
    font-family: 'DM Sans', sans-serif;
    color: #193c2e;
}

.sidebar {
    position: fixed;
    width: 245px;
    height: 100vh;
    background: #153f30;
    padding: 30px 20px;
    color: white;
}

.logo {
    font-size: 25px;
    font-weight: 700;
    padding: 0 15px;
    margin-bottom: 45px;
}

.logo span {
    color: #91bd73;
}

.menu-title {
    color: #91a99d;
    font-size: 12px;
    text-transform: uppercase;
    padding: 0 15px;
    margin-bottom: 12px;
}

.menu a {
    display: block;
    color: #c9d8d1;
    text-decoration: none;
    padding: 13px 15px;
    border-radius: 12px;
    margin-bottom: 5px;
}

.menu a:hover,
.menu a.active {
    background: #285d47;
    color: white;
}

.logout {
    position: absolute;
    bottom: 25px;
    left: 20px;
    right: 20px;
}

.logout a {
    color: #d7aaa3;
}

.content {
    margin-left: 245px;
    padding: 35px 45px;
}

.page-header {
    margin-bottom: 30px;
}

.page-header h1 {
    font-family: 'Playfair Display', serif;
    font-size: 34px;
    margin: 0;
}

.page-header p {
    color: #78877f;
}

.card-custom {
    background: white;
    border: 1px solid #e8ede7;
    border-radius: 22px;
    padding: 28px;
    margin-bottom: 30px;
}

.form-label {
    font-weight: 600;
}

.form-control,
.form-select {
    padding: 12px 14px;
    border-radius: 11px;
}

.btn-simpan {
    background: #174c38;
    color: white;
    border: none;
    border-radius: 11px;
    padding: 12px 22px;
    font-weight: 600;
}

.btn-simpan:hover {
    background: #0f382a;
    color: white;
}

.saldo-info {
    background: #e8f1e2;
    border-radius: 14px;
    padding: 14px 18px;
    margin-top: 10px;
    color: #347050;
}

.status {
    display: inline-block;
    padding: 6px 11px;
    border-radius: 20px;
    font-size: 13px;
    font-weight: 600;
}

.pending {
    background: #fff2cf;
    color: #94701d;
}

.disetujui {
    background: #e1f0e4;
    color: #327047;
}

.ditolak {
    background: #f7e4e1;
    color: #a24f45;
}

.btn-approve {
    color: #347050;
    text-decoration: none;
    font-weight: 600;
}

.btn-reject {
    color: #b45d52;
    text-decoration: none;
    font-weight: 600;
}

</style>

</head>

<body>

<!-- SIDEBAR -->

<div class="sidebar">

    <div class="logo">
        ECO<span>BANK</span>
    </div>

    <div class="menu-title">
        Menu Utama
    </div>

    <div class="menu">

        <a href="dashboard.php">Dashboard</a>

        <a href="nasabah.php">Data Nasabah</a>

        <a href="jenis_sampah.php">Jenis Sampah</a>

        <a href="setoran.php">Setoran Sampah</a>

        <a href="penarikan.php" class="active">
            Penarikan
        </a>

        <a href="laporan.php">Laporan</a>

    </div>

    <div class="logout">
        <a href="../logout.php">Keluar</a>
    </div>

</div>


<!-- CONTENT -->

<div class="content">

    <div class="page-header">

        <h1>Penarikan Saldo</h1>

        <p>
            Kelola permintaan penarikan saldo nasabah.
        </p>

    </div>


    <?php if ($pesan): ?>

        <div class="alert alert-info">
            <?= htmlspecialchars($pesan) ?>
        </div>

    <?php endif; ?>


    <!-- FORM -->

    <div class="card-custom">

        <h5 class="mb-4">
            Buat Penarikan
        </h5>

        <form method="POST">

            <div class="row g-4">

                <div class="col-md-5">

                    <label class="form-label">
                        Nasabah
                    </label>

                    <select
                        name="id_nasabah"
                        class="form-select"
                        required>

                        <option value="">
                            -- Pilih Nasabah --
                        </option>

                        <?php while ($n = mysqli_fetch_assoc($nasabah)): ?>

                            <option value="<?= $n['id_nasabah'] ?>">

                                <?= htmlspecialchars($n['nama']) ?>

                                — Rp <?= number_format(
                                    $n['saldo'],
                                    0,
                                    ',',
                                    '.'
                                ) ?>

                            </option>

                        <?php endwhile; ?>

                    </select>

                </div>


                <div class="col-md-3">

                    <label class="form-label">
                        Tanggal
                    </label>

                    <input
                        type="date"
                        name="tanggal"
                        class="form-control"
                        value="<?= date('Y-m-d') ?>"
                        required>

                </div>


                <div class="col-md-4">

                    <label class="form-label">
                        Jumlah Penarikan
                    </label>

                    <input
                        type="number"
                        name="jumlah"
                        class="form-control"
                        min="1"
                        placeholder="Contoh: 25000"
                        required>

                </div>

            </div>


            <button
                type="submit"
                name="simpan"
                class="btn-simpan mt-4">

                Ajukan Penarikan

            </button>

        </form>

    </div>


    <!-- RIWAYAT -->

    <div class="card-custom">

        <h5 class="mb-4">
            Riwayat Penarikan
        </h5>

        <div class="table-responsive">

            <table class="table align-middle">

                <thead>

                    <tr>
                        <th>No</th>
                        <th>Tanggal</th>
                        <th>Nasabah</th>
                        <th>Jumlah</th>
                        <th>Status</th>
                        <th>Aksi</th>
                    </tr>

                </thead>

                <tbody>

                <?php
                $no = 1;

                while ($row = mysqli_fetch_assoc($data_penarikan)):
                ?>

                    <tr>

                        <td><?= $no++ ?></td>

                        <td>
                            <?= date(
                                'd/m/Y',
                                strtotime($row['tanggal'])
                            ) ?>
                        </td>

                        <td>
                            <strong>
                                <?= htmlspecialchars($row['nama']) ?>
                            </strong>
                        </td>

                        <td>
                            Rp <?= number_format(
                                $row['jumlah'],
                                0,
                                ',',
                                '.'
                            ) ?>
                        </td>

                        <td>

                            <?php if ($row['status'] == 'Pending'): ?>

                                <span class="status pending">
                                    Pending
                                </span>

                            <?php elseif ($row['status'] == 'Disetujui'): ?>

                                <span class="status disetujui">
                                    Disetujui
                                </span>

                            <?php else: ?>

                                <span class="status ditolak">
                                    Ditolak
                                </span>

                            <?php endif; ?>

                        </td>

                        <td>

                            <?php if ($row['status'] == 'Pending'): ?>

                                <a
                                    href="penarikan.php?setujui=<?= $row['id_penarikan'] ?>"
                                    class="btn-approve me-3"
                                    onclick="return confirm('Setujui penarikan ini?')">
                                    Setujui
                                </a>

                                <a
                                    href="penarikan.php?tolak=<?= $row['id_penarikan'] ?>"
                                    class="btn-reject"
                                    onclick="return confirm('Tolak penarikan ini?')">
                                    Tolak
                                </a>

                            <?php else: ?>

                                <span class="text-muted">
                                    —
                                </span>

                            <?php endif; ?>

                        </td>

                    </tr>

                <?php endwhile; ?>

                </tbody>

            </table>

        </div>

    </div>

</div>

</body>
</html>