<?php
session_start();
include "../config/koneksi.php";

if (!isset($_SESSION['id_user']) || $_SESSION['role'] != 'admin') {
    header("Location: ../login.php");
    exit;
}

/* TAMBAH */
if (isset($_POST['simpan'])) {
    $nama = mysqli_real_escape_string($conn, $_POST['nama_sampah']);
    $harga = (float) $_POST['harga_per_kg'];

    mysqli_query($conn, "INSERT INTO jenis_sampah
        (nama_sampah, harga_per_kg)
        VALUES ('$nama', '$harga')");

    header("Location: jenis_sampah.php");
    exit;
}

/* HAPUS */
if (isset($_GET['hapus'])) {
    $id = (int) $_GET['hapus'];

    mysqli_query($conn, "DELETE FROM jenis_sampah
                         WHERE id_sampah = $id");

    header("Location: jenis_sampah.php");
    exit;
}

/* DATA */
$data = mysqli_query($conn,
    "SELECT * FROM jenis_sampah
     ORDER BY id_sampah DESC"
);
?>

<!DOCTYPE html>
<html lang="id">
<head>

<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<title>Jenis Sampah — ECOBANK</title>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">

<link href="https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;500;600;700&family=Playfair+Display:wght@600;700&display=swap" rel="stylesheet">

<style>

body {
    margin: 0;
    background: #f5f7f2;
    font-family: 'DM Sans', sans-serif;
    color: #193c2e;
}

.sidebar {
    position: fixed;
    width: 245px;
    height: 100vh;
    background: #153f30;
    padding: 30px 20px;
    color: white;
}

.logo {
    font-size: 25px;
    font-weight: 700;
    padding: 0 15px;
    margin-bottom: 45px;
}

.logo span {
    color: #91bd73;
}

.menu-title {
    color: #91a99d;
    font-size: 12px;
    text-transform: uppercase;
    padding: 0 15px;
    margin-bottom: 12px;
}

.menu a {
    display: block;
    color: #c9d8d1;
    text-decoration: none;
    padding: 13px 15px;
    border-radius: 12px;
    margin-bottom: 5px;
}

.menu a:hover,
.menu a.active {
    background: #285d47;
    color: white;
}

.logout {
    position: absolute;
    bottom: 25px;
    left: 20px;
    right: 20px;
}

.logout a {
    color: #d7aaa3;
}

.content {
    margin-left: 245px;
    padding: 35px 45px;
}

.page-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 30px;
}

.page-header h1 {
    font-family: 'Playfair Display', serif;
    font-size: 34px;
    margin: 0;
}

.page-header p {
    color: #78877f;
}

.card-custom {
    background: white;
    border: 1px solid #e8ede7;
    border-radius: 22px;
    padding: 28px;
}

.btn-tambah {
    background: #174c38;
    color: white;
    border: none;
    border-radius: 12px;
    padding: 12px 20px;
    font-weight: 600;
}

.btn-edit {
    color: #47755e;
    text-decoration: none;
    font-weight: 600;
}

.btn-hapus {
    color: #b45d52;
    text-decoration: none;
    font-weight: 600;
}

</style>

</head>

<body>

<div class="sidebar">

    <div class="logo">
        ECO<span>BANK</span>
    </div>

    <div class="menu-title">Menu Utama</div>

    <div class="menu">

        <a href="dashboard.php">Dashboard</a>

        <a href="nasabah.php">Data Nasabah</a>

        <a href="jenis_sampah.php" class="active">
            Jenis Sampah
        </a>

        <a href="setoran.php">Setoran Sampah</a>

        <a href="penarikan.php">Penarikan</a>

        <a href="laporan.php">Laporan</a>

    </div>

    <div class="logout">
        <a href="../logout.php">Keluar</a>
    </div>

</div>


<div class="content">

    <div class="page-header">

        <div>
            <h1>Jenis Sampah</h1>

            <p>
                Kelola jenis sampah dan harga per kilogram.
            </p>
        </div>

        <button
            class="btn-tambah"
            data-bs-toggle="modal"
            data-bs-target="#modalTambah">
            + Tambah Jenis
        </button>

    </div>


    <div class="card-custom">

        <div class="table-responsive">

            <table class="table align-middle">

                <thead>
                    <tr>
                        <th>No</th>
                        <th>Jenis Sampah</th>
                        <th>Harga / Kg</th>
                        <th>Aksi</th>
                    </tr>
                </thead>

                <tbody>

                <?php
                $no = 1;

                while ($row = mysqli_fetch_assoc($data)):
                ?>

                <tr>

                    <td><?= $no++ ?></td>

                    <td>
                        <strong>
                            <?= htmlspecialchars($row['nama_sampah']) ?>
                        </strong>
                    </td>

                    <td>
                        Rp <?= number_format(
                            $row['harga_per_kg'],
                            0,
                            ',',
                            '.'
                        ) ?>
                    </td>

                    <td>

                        <a href="#"
                           class="btn-edit me-3">
                            Edit
                        </a>

                        <a
                            href="jenis_sampah.php?hapus=<?= $row['id_sampah'] ?>"
                            class="btn-hapus"
                            onclick="return confirm('Hapus jenis sampah ini?')">
                            Hapus
                        </a>

                    </td>

                </tr>

                <?php endwhile; ?>

                </tbody>

            </table>

        </div>

    </div>

</div>


<!-- MODAL -->

<div class="modal fade" id="modalTambah">

    <div class="modal-dialog modal-dialog-centered">

        <div class="modal-content">

            <form method="POST">

                <div class="modal-header">

                    <h5 class="modal-title">
                        Tambah Jenis Sampah
                    </h5>

                    <button
                        type="button"
                        class="btn-close"
                        data-bs-dismiss="modal">
                    </button>

                </div>

                <div class="modal-body">

                    <div class="mb-3">

                        <label class="form-label">
                            Nama Sampah
                        </label>

                        <input
                            type="text"
                            name="nama_sampah"
                            class="form-control"
                            placeholder="Contoh: Botol Plastik"
                            required>

                    </div>

                    <div class="mb-3">

                        <label class="form-label">
                            Harga per Kg
                        </label>

                        <input
                            type="number"
                            name="harga_per_kg"
                            class="form-control"
                            placeholder="4000"
                            required>

                    </div>

                </div>

                <div class="modal-footer">

                    <button
                        type="button"
                        class="btn btn-light"
                        data-bs-dismiss="modal">
                        Batal
                    </button>

                    <button
                        type="submit"
                        name="simpan"
                        class="btn btn-success">
                        Simpan
                    </button>

                </div>

            </form>

        </div>

    </div>

</div>


<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>

</body>
</html>