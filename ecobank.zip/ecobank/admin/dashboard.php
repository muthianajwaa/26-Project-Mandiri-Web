<?php
session_start();
include "../config/koneksi.php";

if (!isset($_SESSION['id_user']) || $_SESSION['role'] != 'admin') {
    header("Location: ../login.php");
    exit;
}

/* DATA DASHBOARD */

$query_nasabah = mysqli_query($conn, "SELECT COUNT(*) AS total FROM nasabah");
$total_nasabah = mysqli_fetch_assoc($query_nasabah)['total'];

$query_setoran = mysqli_query($conn, "SELECT COUNT(*) AS total FROM setoran");
$total_setoran = mysqli_fetch_assoc($query_setoran)['total'];

$query_berat = mysqli_query($conn, "SELECT COALESCE(SUM(berat),0) AS total FROM setoran");
$total_berat = mysqli_fetch_assoc($query_berat)['total'];

$query_penarikan = mysqli_query($conn, "SELECT COUNT(*) AS total FROM penarikan");
$total_penarikan = mysqli_fetch_assoc($query_penarikan)['total'];

?>

<!DOCTYPE html>
<html lang="id">
<head>

    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Dashboard Admin — ECOBANK</title>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">

    <link href="https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;500;600;700&family=Playfair+Display:wght@600;700&display=swap" rel="stylesheet">

    <style>

        * {
            box-sizing: border-box;
        }

        body {
            margin: 0;
            background: #f5f7f2;
            font-family: 'DM Sans', sans-serif;
            color: #193c2e;
        }

        /* SIDEBAR */

        .sidebar {
            position: fixed;
            width: 245px;
            height: 100vh;
            background: #153f30;
            padding: 30px 20px;
            color: white;
        }

        .logo {
            font-size: 25px;
            font-weight: 700;
            letter-spacing: 1px;
            padding: 0 15px;
            margin-bottom: 45px;
        }

        .logo span {
            color: #91bd73;
        }

        .menu-title {
            color: #91a99d;
            font-size: 12px;
            text-transform: uppercase;
            letter-spacing: 1px;
            padding: 0 15px;
            margin-bottom: 12px;
        }

        .menu a {
            display: block;
            color: #c9d8d1;
            text-decoration: none;
            padding: 13px 15px;
            border-radius: 12px;
            margin-bottom: 5px;
            transition: .2s;
        }

        .menu a:hover,
        .menu a.active {
            background: #285d47;
            color: white;
        }

        .logout {
            position: absolute;
            bottom: 25px;
            left: 20px;
            right: 20px;
        }

        .logout a {
            color: #d7aaa3;
        }

        /* CONTENT */

        .content {
            margin-left: 245px;
            padding: 35px 45px;
        }

        .topbar {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 35px;
        }

        .topbar h1 {
            font-family: 'Playfair Display', serif;
            font-size: 34px;
            margin: 0;
        }

        .welcome {
            color: #75847c;
            margin-top: 5px;
        }

        .profile {
            background: white;
            padding: 11px 18px;
            border-radius: 30px;
            box-shadow: 0 5px 20px rgba(30,60,45,.05);
            font-weight: 600;
        }

        /* CARDS */

        .stat-card {
            background: white;
            border-radius: 20px;
            padding: 25px;
            border: 1px solid #e9eee8;
            height: 100%;
            transition: .2s;
        }

        .stat-card:hover {
            transform: translateY(-4px);
            box-shadow: 0 12px 30px rgba(30,60,45,.08);
        }

        .stat-icon {
            width: 48px;
            height: 48px;
            border-radius: 14px;
            background: #e6f0df;
            display: flex;
            align-items: center;
            justify-content: center;
            color: #347050;
            font-weight: 700;
            margin-bottom: 20px;
        }

        .stat-number {
            font-size: 30px;
            font-weight: 700;
            color: #173f30;
        }

        .stat-label {
            color: #7b8982;
            margin-top: 3px;
        }

        /* SECTION */

        .section-card {
            background: white;
            border-radius: 22px;
            padding: 28px;
            border: 1px solid #e9eee8;
            margin-top: 30px;
        }

        .section-title {
            font-weight: 700;
            font-size: 19px;
            margin-bottom: 5px;
        }

        .section-desc {
            color: #7b8982;
            font-size: 14px;
        }

        .quick-card {
            background: #f5f8f2;
            border-radius: 15px;
            padding: 20px;
            text-decoration: none;
            color: #214b38;
            display: block;
            height: 100%;
            transition: .2s;
        }

        .quick-card:hover {
            background: #e8f1e2;
            color: #214b38;
            transform: translateY(-3px);
        }

        .quick-card strong {
            display: block;
            margin-bottom: 5px;
        }

        .quick-card span {
            color: #78877f;
            font-size: 13px;
        }

        @media(max-width: 900px) {

            .sidebar {
                width: 190px;
            }

            .content {
                margin-left: 190px;
                padding: 25px;
            }

        }

        @media(max-width: 650px) {

            .sidebar {
                position: static;
                width: 100%;
                height: auto;
            }

            .logout {
                position: static;
                margin-top: 20px;
            }

            .content {
                margin-left: 0;
            }

        }

    </style>

</head>

<body>


<!-- SIDEBAR -->

<div class="sidebar">

    <div class="logo">
        ECO<span>BANK</span>
    </div>

    <div class="menu-title">
        Menu Utama
    </div>

    <div class="menu">

        <a href="dashboard.php" class="active">
            Dashboard
        </a>

        <a href="nasabah.php">
            Data Nasabah
        </a>

        <a href="jenis_sampah.php">
            Jenis Sampah
        </a>

        <a href="setoran.php">
            Setoran Sampah
        </a>

        <a href="penarikan.php">
            Penarikan
        </a>

        <a href="laporan.php">
            Laporan
        </a>

    </div>

    <div class="logout">

        <a href="../logout.php" class="menu">
            Keluar
        </a>

    </div>

</div>


<!-- CONTENT -->

<div class="content">

    <div class="topbar">

        <div>

            <h1>Dashboard</h1>

            <div class="welcome">
                Selamat datang kembali di ECOBANK.
            </div>

        </div>

        <div class="profile">
            Admin Muti
        </div>

    </div>


    <!-- STATISTIK -->

    <div class="row g-4">

        <div class="col-lg-3 col-md-6">

            <div class="stat-card">

                <div class="stat-icon">
                    N
                </div>

                <div class="stat-number">
                    <?= $total_nasabah ?>
                </div>

                <div class="stat-label">
                    Total Nasabah
                </div>

            </div>

        </div>


        <div class="col-lg-3 col-md-6">

            <div class="stat-card">

                <div class="stat-icon">
                    S
                </div>

                <div class="stat-number">
                    <?= $total_setoran ?>
                </div>

                <div class="stat-label">
                    Total Setoran
                </div>

            </div>

        </div>


        <div class="col-lg-3 col-md-6">

            <div class="stat-card">

                <div class="stat-icon">
                    KG
                </div>

                <div class="stat-number">
                    <?= number_format($total_berat, 1) ?>
                </div>

                <div class="stat-label">
                    Sampah Terkumpul (Kg)
                </div>

            </div>

        </div>


        <div class="col-lg-3 col-md-6">

            <div class="stat-card">

                <div class="stat-icon">
                    P
                </div>

                <div class="stat-number">
                    <?= $total_penarikan ?>
                </div>

                <div class="stat-label">
                    Penarikan
                </div>

            </div>

        </div>

    </div>


    <!-- AKSI CEPAT -->

    <div class="section-card">

        <div class="section-title">
            Aksi Cepat
        </div>

        <div class="section-desc mb-4">
            Kelola data ECOBANK melalui menu berikut.
        </div>


        <div class="row g-3">

            <div class="col-md-4">

                <a href="nasabah.php" class="quick-card">

                    <strong>+ Tambah Nasabah</strong>

                    <span>
                        Tambahkan data nasabah baru.
                    </span>

                </a>

            </div>


            <div class="col-md-4">

                <a href="setoran.php" class="quick-card">

                    <strong>+ Catat Setoran</strong>

                    <span>
                        Input transaksi sampah masuk.
                    </span>

                </a>

            </div>


            <div class="col-md-4">

                <a href="laporan.php" class="quick-card">

                    <strong>Lihat Laporan</strong>

                    <span>
                        Lihat dan cetak laporan transaksi.
                    </span>

                </a>

            </div>

        </div>

    </div>


    <!-- INFO -->

    <div class="section-card">

        <div class="section-title">
            Tentang Dashboard
        </div>

        <div class="section-desc">
            Dashboard digunakan oleh admin untuk memantau data
            nasabah, transaksi setoran, jumlah sampah yang terkumpul,
            dan penarikan saldo ECOBANK.
        </div>

    </div>

</div>


</body>
</html>