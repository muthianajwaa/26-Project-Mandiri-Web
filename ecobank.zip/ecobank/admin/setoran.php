<?php
session_start();
include "../config/koneksi.php";

if (!isset($_SESSION['id_user']) || $_SESSION['role'] != 'admin') {
    header("Location: ../login.php");
    exit;
}

$pesan = "";

/* SIMPAN SETORAN */
if (isset($_POST['simpan'])) {

    $id_nasabah = (int) $_POST['id_nasabah'];
    $id_sampah  = (int) $_POST['id_sampah'];
    $tanggal    = $_POST['tanggal'];
    $berat      = (float) $_POST['berat'];

    /* Ambil harga sampah */
    $query_harga = mysqli_query(
        $conn,
        "SELECT harga_per_kg
         FROM jenis_sampah
         WHERE id_sampah = $id_sampah"
    );

    $data_harga = mysqli_fetch_assoc($query_harga);

    if (!$data_harga) {
        $pesan = "Jenis sampah tidak ditemukan.";
    } else {

        $harga = (float) $data_harga['harga_per_kg'];

        /* Hitung total */
        $total_harga = $berat * $harga;

        /* Simpan transaksi */
        $simpan = mysqli_query(
            $conn,
            "INSERT INTO setoran
            (id_nasabah, id_sampah, tanggal, berat, total_harga)
            VALUES
            ($id_nasabah, $id_sampah, '$tanggal', $berat, $total_harga)"
        );

        if ($simpan) {

            /* Tambahkan ke saldo nasabah */
            mysqli_query(
                $conn,
                "UPDATE nasabah
                 SET saldo = saldo + $total_harga
                 WHERE id_nasabah = $id_nasabah"
            );

            $pesan = "Setoran berhasil disimpan!";
        } else {
            $pesan = "Setoran gagal disimpan.";
        }
    }
}


/* DATA NASABAH */
$nasabah = mysqli_query(
    $conn,
    "SELECT id_nasabah, nama
     FROM nasabah
     ORDER BY nama ASC"
);


/* DATA JENIS SAMPAH */
$jenis_sampah = mysqli_query(
    $conn,
    "SELECT id_sampah, nama_sampah, harga_per_kg
     FROM jenis_sampah
     ORDER BY nama_sampah ASC"
);


/* RIWAYAT SETORAN */
$riwayat = mysqli_query(
    $conn,
    "SELECT
        setoran.*,
        nasabah.nama,
        jenis_sampah.nama_sampah
     FROM setoran
     JOIN nasabah
        ON setoran.id_nasabah = nasabah.id_nasabah
     JOIN jenis_sampah
        ON setoran.id_sampah = jenis_sampah.id_sampah
     ORDER BY setoran.id_setoran DESC"
);

?>

<!DOCTYPE html>
<html lang="id">

<head>

<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<title>Setoran Sampah — ECOBANK</title>

<link
href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css"
rel="stylesheet">

<link
href="https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;500;600;700&family=Playfair+Display:wght@600;700&display=swap"
rel="stylesheet">

<style>

body {
    margin: 0;
    background: #f5f7f2;
    font-family: 'DM Sans', sans-serif;
    color: #193c2e;
}

.sidebar {
    position: fixed;
    width: 245px;
    height: 100vh;
    background: #153f30;
    padding: 30px 20px;
    color: white;
}

.logo {
    font-size: 25px;
    font-weight: 700;
    padding: 0 15px;
    margin-bottom: 45px;
}

.logo span {
    color: #91bd73;
}

.menu-title {
    color: #91a99d;
    font-size: 12px;
    text-transform: uppercase;
    padding: 0 15px;
    margin-bottom: 12px;
}

.menu a {
    display: block;
    color: #c9d8d1;
    text-decoration: none;
    padding: 13px 15px;
    border-radius: 12px;
    margin-bottom: 5px;
}

.menu a:hover,
.menu a.active {
    background: #285d47;
    color: white;
}

.logout {
    position: absolute;
    bottom: 25px;
    left: 20px;
    right: 20px;
}

.logout a {
    color: #d7aaa3;
}

.content {
    margin-left: 245px;
    padding: 35px 45px;
}

.page-header {
    margin-bottom: 30px;
}

.page-header h1 {
    font-family: 'Playfair Display', serif;
    font-size: 34px;
    margin: 0;
}

.page-header p {
    color: #78877f;
    margin-top: 5px;
}

.card-custom {
    background: white;
    border: 1px solid #e8ede7;
    border-radius: 22px;
    padding: 28px;
    margin-bottom: 30px;
}

.form-label {
    font-weight: 600;
    color: #365247;
}

.form-control,
.form-select {
    padding: 12px 14px;
    border-radius: 11px;
    border: 1px solid #dfe6df;
}

.btn-simpan {
    background: #174c38;
    color: white;
    border: none;
    border-radius: 11px;
    padding: 12px 22px;
    font-weight: 600;
}

.btn-simpan:hover {
    background: #0f382a;
    color: white;
}

.total-box {
    background: #e8f1e2;
    border-radius: 16px;
    padding: 20px;
    margin-top: 20px;
}

.total-label {
    color: #64796d;
    font-size: 14px;
}

.total-value {
    color: #174c38;
    font-size: 30px;
    font-weight: 700;
}

.table {
    vertical-align: middle;
}

.table thead th {
    color: #718078;
    font-size: 13px;
    border-bottom: 1px solid #e5ebe4;
}

.table tbody td {
    padding-top: 17px;
    padding-bottom: 17px;
}

</style>

</head>

<body>


<!-- SIDEBAR -->

<div class="sidebar">

    <div class="logo">
        ECO<span>BANK</span>
    </div>

    <div class="menu-title">
        Menu Utama
    </div>

    <div class="menu">

        <a href="dashboard.php">
            Dashboard
        </a>

        <a href="nasabah.php">
            Data Nasabah
        </a>

        <a href="jenis_sampah.php">
            Jenis Sampah
        </a>

        <a href="setoran.php" class="active">
            Setoran Sampah
        </a>

        <a href="penarikan.php">
            Penarikan
        </a>

        <a href="laporan.php">
            Laporan
        </a>

    </div>

    <div class="logout">
        <a href="../logout.php">
            Keluar
        </a>
    </div>

</div>


<!-- CONTENT -->

<div class="content">

    <div class="page-header">

        <h1>Setoran Sampah</h1>

        <p>
            Catat setoran sampah dan tambahkan nilai ke saldo nasabah.
        </p>

    </div>


    <?php if ($pesan): ?>

        <div class="alert alert-success">
            <?= htmlspecialchars($pesan) ?>
        </div>

    <?php endif; ?>


    <!-- FORM SETORAN -->

    <div class="card-custom">

        <h5 class="mb-4">
            Tambah Setoran
        </h5>

        <form method="POST">

            <div class="row g-4">

                <div class="col-md-6">

                    <label class="form-label">
                        Nasabah
                    </label>

                    <select
                        name="id_nasabah"
                        id="nasabah"
                        class="form-select"
                        required>

                        <option value="">
                            -- Pilih Nasabah --
                        </option>

                        <?php while ($n = mysqli_fetch_assoc($nasabah)): ?>

                            <option value="<?= $n['id_nasabah'] ?>">
                                <?= htmlspecialchars($n['nama']) ?>
                            </option>

                        <?php endwhile; ?>

                    </select>

                </div>


                <div class="col-md-6">

                    <label class="form-label">
                        Jenis Sampah
                    </label>

                    <select
                        name="id_sampah"
                        id="jenisSampah"
                        class="form-select"
                        required>

                        <option value="">
                            -- Pilih Jenis Sampah --
                        </option>

                        <?php while ($s = mysqli_fetch_assoc($jenis_sampah)): ?>

                            <option
                                value="<?= $s['id_sampah'] ?>"
                                data-harga="<?= $s['harga_per_kg'] ?>">

                                <?= htmlspecialchars($s['nama_sampah']) ?>

                                —
                                Rp <?= number_format(
                                    $s['harga_per_kg'],
                                    0,
                                    ',',
                                    '.'
                                ) ?>/kg

                            </option>

                        <?php endwhile; ?>

                    </select>

                </div>


                <div class="col-md-4">

                    <label class="form-label">
                        Tanggal
                    </label>

                    <input
                        type="date"
                        name="tanggal"
                        class="form-control"
                        value="<?= date('Y-m-d') ?>"
                        required>

                </div>


                <div class="col-md-4">

                    <label class="form-label">
                        Berat (Kg)
                    </label>

                    <input
                        type="number"
                        name="berat"
                        id="berat"
                        class="form-control"
                        step="0.01"
                        min="0.01"
                        placeholder="Contoh: 3"
                        required>

                </div>


                <div class="col-md-4">

                    <label class="form-label">
                        Harga / Kg
                    </label>

                    <input
                        type="text"
                        id="harga"
                        class="form-control"
                        value="Rp 0"
                        readonly>

                </div>

            </div>


            <div class="total-box">

                <div class="total-label">
                    Total Nilai Setoran
                </div>

                <div
                    class="total-value"
                    id="total">
                    Rp 0
                </div>

            </div>


            <button
                type="submit"
                name="simpan"
                class="btn-simpan mt-4">

                Simpan Setoran

            </button>

        </form>

    </div>


    <!-- RIWAYAT -->

    <div class="card-custom">

        <h5 class="mb-4">
            Riwayat Setoran
        </h5>

        <div class="table-responsive">

            <table class="table">

                <thead>

                    <tr>
                        <th>No</th>
                        <th>Tanggal</th>
                        <th>Nasabah</th>
                        <th>Jenis Sampah</th>
                        <th>Berat</th>
                        <th>Total</th>
                    </tr>

                </thead>

                <tbody>

                <?php
                $no = 1;

                while ($r = mysqli_fetch_assoc($riwayat)):
                ?>

                    <tr>

                        <td><?= $no++ ?></td>

                        <td>
                            <?= date(
                                'd/m/Y',
                                strtotime($r['tanggal'])
                            ) ?>
                        </td>

                        <td>
                            <?= htmlspecialchars($r['nama']) ?>
                        </td>

                        <td>
                            <?= htmlspecialchars(
                                $r['nama_sampah']
                            ) ?>
                        </td>

                        <td>
                            <?= $r['berat'] ?> Kg
                        </td>

                        <td>
                            <strong>
                                Rp <?= number_format(
                                    $r['total_harga'],
                                    0,
                                    ',',
                                    '.'
                                ) ?>
                            </strong>
                        </td>

                    </tr>

                <?php endwhile; ?>

                </tbody>

            </table>

        </div>

    </div>

</div>


<script>

const jenisSampah =
    document.getElementById('jenisSampah');

const berat =
    document.getElementById('berat');

const harga =
    document.getElementById('harga');

const total =
    document.getElementById('total');


function hitungTotal() {

    const selected =
        jenisSampah.options[
            jenisSampah.selectedIndex
        ];

    const hargaKg =
        selected.dataset.harga || 0;

    const beratValue =
        parseFloat(berat.value) || 0;

    const hasil =
        hargaKg * beratValue;

    harga.value =
        'Rp ' +
        Number(hargaKg).toLocaleString('id-ID');

    total.innerText =
        'Rp ' +
        hasil.toLocaleString('id-ID');
}


jenisSampah.addEventListener(
    'change',
    hitungTotal
);

berat.addEventListener(
    'input',
    hitungTotal
);

</script>

</body>
</html>