<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>ECOBANK — Bank Sampah Digital</title>

    <!-- Bootstrap -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">

    <!-- Google Font -->
    <link href="https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;500;600;700&family=Playfair+Display:wght@600;700&display=swap" rel="stylesheet">

    <style>
        * {
            box-sizing: border-box;
        }

        body {
            margin: 0;
            font-family: 'DM Sans', sans-serif;
            background: #f7f8f3;
            color: #18352a;
        }

        /* NAVBAR */
        .navbar {
            padding: 22px 0;
            background: rgba(247,248,243,0.96);
        }

        .brand {
            font-size: 25px;
            font-weight: 700;
            color: #164b38;
            letter-spacing: 1px;
        }

        .brand span {
            color: #7caa62;
        }

        .nav-link {
            color: #486057 !important;
            font-weight: 500;
            margin-left: 20px;
        }

        .nav-link:hover {
            color: #277052 !important;
        }

        .btn-login {
            background: #164b38;
            color: white;
            padding: 11px 24px;
            border-radius: 30px;
            text-decoration: none;
            font-weight: 600;
            margin-left: 20px;
        }

        .btn-login:hover {
            background: #0f382a;
            color: white;
        }

        /* HERO */
        .hero {
            padding: 65px 0 80px;
        }

        .hero h1 {
            font-family: 'Playfair Display', serif;
            font-size: clamp(45px, 5vw, 72px);
            line-height: 1.05;
            color: #163f30;
            margin-bottom: 25px;
        }

        .hero h1 span {
            color: #7da866;
        }

        .hero p {
            color: #65776f;
            font-size: 17px;
            line-height: 1.8;
            max-width: 540px;
        }

        .btn-main {
            display: inline-block;
            background: #164b38;
            color: white;
            padding: 14px 28px;
            border-radius: 30px;
            text-decoration: none;
            font-weight: 600;
            margin-top: 15px;
        }

        .btn-main:hover {
            background: #0e3829;
            color: white;
        }

        .hero-image {
            height: 470px;
            border-radius: 30px;
            background:
                linear-gradient(rgba(20,65,48,.05), rgba(20,65,48,.1)),
                url('https://images.unsplash.com/photo-1532996122724-e3c354a0b15b?auto=format&fit=crop&w=1000&q=85');
            background-size: cover;
            background-position: center;
            box-shadow: 0 25px 60px rgba(31,70,52,.15);
        }

        /* STATS */
        .stats {
            margin-top: -30px;
            position: relative;
        }

        .stat-box {
            background: white;
            padding: 28px;
            border-radius: 20px;
            box-shadow: 0 12px 35px rgba(35,65,50,.08);
            height: 100%;
        }

        .stat-number {
            font-size: 30px;
            font-weight: 700;
            color: #164b38;
        }

        .stat-label {
            color: #718078;
            margin-top: 5px;
        }

        /* SECTION */
        .section {
            padding: 100px 0;
        }

        .section-title {
            font-family: 'Playfair Display', serif;
            font-size: 42px;
            color: #173f30;
        }

        .section-subtitle {
            color: #718078;
            max-width: 600px;
            margin: 15px auto 50px;
            line-height: 1.7;
        }

        /* STEPS */
        .step-card {
            background: white;
            border-radius: 22px;
            padding: 32px;
            height: 100%;
            border: 1px solid #edf0ea;
            transition: .3s;
        }

        .step-card:hover {
            transform: translateY(-7px);
            box-shadow: 0 15px 35px rgba(35,65,50,.1);
        }

        .step-number {
            width: 48px;
            height: 48px;
            border-radius: 50%;
            background: #e5f0df;
            color: #2b674b;
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: 700;
            margin-bottom: 25px;
        }

        .step-card h5 {
            font-weight: 700;
        }

        .step-card p {
            color: #718078;
            line-height: 1.7;
        }

        /* WASTE */
        .waste-card {
            background: white;
            border-radius: 22px;
            overflow: hidden;
            border: 1px solid #edf0ea;
            height: 100%;
        }

        .waste-image {
            height: 190px;
            background-size: cover;
            background-position: center;
        }

        .waste-content {
            padding: 22px;
        }

        .price {
            color: #6c9d55;
            font-weight: 700;
            margin-top: 10px;
        }

        /* CTA */
        .impact {
            background: #174c38;
            border-radius: 30px;
            padding: 65px;
            color: white;
            overflow: hidden;
        }

        .impact h2 {
            font-family: 'Playfair Display', serif;
            font-size: 42px;
        }

        .impact p {
            color: #cbdcd3;
            line-height: 1.7;
        }

        .btn-light-custom {
            background: white;
            color: #174c38;
            padding: 13px 25px;
            border-radius: 30px;
            text-decoration: none;
            display: inline-block;
            font-weight: 600;
            margin-top: 12px;
        }

        /* FOOTER */
        footer {
            background: #102f25;
            color: #b8c9c0;
            padding: 55px 0 25px;
            margin-top: 100px;
        }

        footer h4 {
            color: white;
            font-weight: 700;
        }

        footer p {
            line-height: 1.8;
        }

        .copyright {
            border-top: 1px solid rgba(255,255,255,.1);
            margin-top: 40px;
            padding-top: 20px;
            font-size: 14px;
        }

        @media(max-width: 768px) {
            .hero {
                padding-top: 30px;
            }

            .hero-image {
                height: 330px;
                margin-top: 40px;
            }

            .impact {
                padding: 40px 25px;
            }
        }
    </style>
</head>

<body>

<!-- NAVBAR -->
<nav class="navbar navbar-expand-lg">
    <div class="container">

        <a class="brand text-decoration-none" href="#">
            ECO<span>BANK</span>
        </a>

        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#menu">
            ☰
        </button>

        <div class="collapse navbar-collapse" id="menu">
            <ul class="navbar-nav ms-auto align-items-lg-center">
                <li class="nav-item">
                    <a class="nav-link" href="#">Beranda</a>
                </li>

                <li class="nav-item">
                    <a class="nav-link" href="#tentang">Tentang</a>
                </li>

                <li class="nav-item">
                    <a class="nav-link" href="#cara-kerja">Cara Kerja</a>
                </li>

                <li class="nav-item">
                    <a class="nav-link" href="#sampah">Jenis Sampah</a>
                </li>

                <li class="nav-item">
                    <a class="btn-login" href="login.php">Masuk</a>
                </li>
            </ul>
        </div>

    </div>
</nav>


<!-- HERO -->
<section class="hero">
    <div class="container">

        <div class="row align-items-center">

            <div class="col-lg-6">

                <p style="color:#6c9d55;font-weight:700;letter-spacing:2px;">
                    BANK SAMPAH DIGITAL
                </p>

                <h1>
                    Membangun Kepedulian,
                    <span>Menciptakan Perubahan.</span>
                </h1>

                <p>
                    ECOBANK membantu masyarakat mengelola sampah
                    menjadi sesuatu yang lebih bernilai, sekaligus
                    menciptakan lingkungan yang lebih bersih dan berkelanjutan.
                </p>

                <a href="login.php" class="btn-main">
                    Mulai Sekarang →
                </a>

            </div>

            <div class="col-lg-6">
                <div class="hero-image"></div>
            </div>

        </div>

    </div>
</section>


<!-- STATS -->
<section class="stats">
    <div class="container">

        <div class="row g-4">

            <div class="col-md-4">
                <div class="stat-box">
                    <div class="stat-number">0 Kg</div>
                    <div class="stat-label">Sampah Terkumpul</div>
                </div>
            </div>

            <div class="col-md-4">
                <div class="stat-box">
                    <div class="stat-number">0</div>
                    <div class="stat-label">Nasabah Aktif</div>
                </div>
            </div>

            <div class="col-md-4">
                <div class="stat-box">
                    <div class="stat-number">0</div>
                    <div class="stat-label">Transaksi</div>
                </div>
            </div>

        </div>

    </div>
</section>


<!-- TENTANG -->
<section class="section" id="tentang">
    <div class="container text-center">

        <h2 class="section-title">
            Sampah Bisa Jadi Berkah
        </h2>

        <p class="section-subtitle">
            Dengan memilah dan menyetorkan sampah melalui ECOBANK,
            masyarakat tidak hanya membantu menjaga lingkungan,
            tetapi juga mendapatkan nilai ekonomi dari sampah yang dikumpulkan.
        </p>

    </div>
</section>


<!-- CARA KERJA -->
<section class="section pt-0" id="cara-kerja">
    <div class="container">

        <div class="text-center mb-5">
            <h2 class="section-title">Cara Kerja ECOBANK</h2>
            <p class="section-subtitle">
                Proses sederhana untuk mengubah sampah menjadi manfaat.
            </p>
        </div>

        <div class="row g-4">

            <div class="col-md-3">
                <div class="step-card">
                    <div class="step-number">01</div>
                    <h5>Pilah</h5>
                    <p>
                        Pisahkan sampah berdasarkan jenisnya agar
                        lebih mudah dikelola dan didaur ulang.
                    </p>
                </div>
            </div>

            <div class="col-md-3">
                <div class="step-card">
                    <div class="step-number">02</div>
                    <h5>Setor</h5>
                    <p>
                        Bawa sampah yang sudah dipilah ke bank sampah
                        untuk ditimbang oleh petugas.
                    </p>
                </div>
            </div>

            <div class="col-md-3">
                <div class="step-card">
                    <div class="step-number">03</div>
                    <h5>Dapatkan Saldo</h5>
                    <p>
                        Berat sampah dihitung berdasarkan harga
                        per kilogram dan masuk ke saldo nasabah.
                    </p>
                </div>
            </div>

            <div class="col-md-3">
                <div class="step-card">
                    <div class="step-number">04</div>
                    <h5>Jaga Lingkungan</h5>
                    <p>
                        Sampah lebih terkelola dan lingkungan
                        menjadi lebih bersih serta nyaman.
                    </p>
                </div>
            </div>

        </div>

    </div>
</section>


<!-- JENIS SAMPAH -->
<section class="section pt-0" id="sampah">
    <div class="container">

        <div class="text-center mb-5">
            <h2 class="section-title">Jenis Sampah</h2>
            <p class="section-subtitle">
                Beberapa jenis sampah yang dapat disetorkan melalui ECOBANK.
            </p>
        </div>

        <div class="row g-4">

            <div class="col-md-3">
                <div class="waste-card">
                    <div class="waste-image"
                         style="background-image:url('https://images.unsplash.com/photo-1605600659908-0ef719419d41?auto=format&fit=crop&w=700&q=80')">
                    </div>

                    <div class="waste-content">
                        <h5>Botol Plastik</h5>
                        <div class="price">Rp4.000 / kg</div>
                    </div>
                </div>
            </div>

            <div class="col-md-3">
                <div class="waste-card">
                    <div class="waste-image"
                         style="background-image:url('https://images.unsplash.com/photo-1604187351574-c75ca79f5807?auto=format&fit=crop&w=700&q=80')">
                    </div>

                    <div class="waste-content">
                        <h5>Kardus</h5>
                        <div class="price">Rp3.000 / kg</div>
                    </div>
                </div>
            </div>

            <div class="col-md-3">
                <div class="waste-card">
                    <div class="waste-image"
                         style="background-image:url('https://images.unsplash.com/photo-1610557892470-55f6f1c9f2a0?auto=format&fit=crop&w=700&q=80')">
                    </div>

                    <div class="waste-content">
                        <h5>Kaleng</h5>
                        <div class="price">Rp5.000 / kg</div>
                    </div>
                </div>
            </div>

            <div class="col-md-3">
                <div class="waste-card">
                    <div class="waste-image"
                         style="background-image:url('https://images.unsplash.com/photo-1604187351574-c75ca79f5807?auto=format&fit=crop&w=700&q=80')">
                    </div>

                    <div class="waste-content">
                        <h5>Botol Kaca</h5>
                        <div class="price">Rp2.000 / kg</div>
                    </div>
                </div>
            </div>

        </div>

    </div>
</section>


<!-- CTA -->
<section class="container">
    <div class="impact">

        <div class="row align-items-center">

            <div class="col-lg-8">
                <h2>
                    Satu Kebiasaan Kecil,
                    Dampak yang Besar.
                </h2>

                <p>
                    Mulai dari memilah sampah di rumah.
                    ECOBANK membantu menjadikan kebiasaan tersebut
                    lebih mudah, terorganisir, dan bernilai.
                </p>
            </div>

            <div class="col-lg-4 text-lg-end">
                <a href="login.php" class="btn-light-custom">
                    Gabung ECOBANK →
                </a>
            </div>

        </div>

    </div>
</section>


<!-- FOOTER -->
<footer>
    <div class="container">

        <div class="row">

            <div class="col-md-6">
                <h4>ECOBANK</h4>
                <p>
                    Membangun Kepedulian, Menciptakan Perubahan.
                    <br>
                    Sistem informasi bank sampah berbasis web.
                </p>
            </div>

            <div class="col-md-6 text-md-end">
                <p>
                    Kelola sampah.<br>
                    Dapatkan manfaat.<br>
                    Jaga lingkungan.
                </p>
            </div>

        </div>

        <div class="copyright">
            © 2026 ECOBANK. All Rights Reserved.
        </div>

    </div>
</footer>


<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>

</body>
</html>